function setup() {
  createCanvas(600, 400);
  background (245);
  noStroke();
  fill(163, 230, 30);
  for (let x = 40; x < 550; x += 90) {
    rect(x, random(100, 250) , 60, 60);
  }
}
