function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(97, 232, 145);
  noStroke();
  if (mouseIsPressed) {
    fill(222, 101, 20);
  } else {
    fill(232, 97, 203);
  }
  rect(100, 100, 400, 200);
}