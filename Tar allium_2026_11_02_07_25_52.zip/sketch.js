function setup() {
  createCanvas(600, 360);
  background(20);
  noStroke();
  fill(255,220,140);
  randomSeed(7);
  for (let x = 50; x < 600; x += 50) {
    let y = random(40,320);
    circle(x,y,12);
  }
}
