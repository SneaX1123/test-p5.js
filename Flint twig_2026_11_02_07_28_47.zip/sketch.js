function setup() {
  createCanvas(600, 360);
}

function draw() {
  background(240);
  noStroke();
  fill(25,120,110);
  let x = constrain(mouseX,30,570);
  circle(x,180,60);
}